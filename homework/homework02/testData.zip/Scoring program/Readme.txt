1. 確認已安裝java
https://www.java.com/zh-TW/download/

2. 在使用之前需要準備以下檔案
players.txt
orders.txt
recipes.txt
於此資料夾內，使用後會產生output.txt

3. 點兩下執行