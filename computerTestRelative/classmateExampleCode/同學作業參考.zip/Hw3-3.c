#include <stdio.h>
#include <stdlib.h>

typedef struct treeNode *treePointer;
struct treeNode{
	int x, y;
	char c;
	struct treeNode *leftChild;
	struct treeNode *rightChild;
};

char color;
FILE *input, *output;

treePointer buildTree(int x, int y){

	treePointer temp = (treePointer) malloc(sizeof(struct treeNode));

	temp->x = x;
	temp->y = y;
	temp->c = '\n';

	if( x!= y ){
		temp->leftChild = buildTree(x, (x+y)/2);
		temp->rightChild = buildTree((x+y)/2+1, y);
	}
	else{
		temp->leftChild = NULL;
		temp->rightChild = NULL;
	}

	return temp;
}

void paint(int x, int y, char c, treePointer node){

	if( x <= node->x && y >= node->y ){
		node->c = c;
		return;
	}

	int middle = (node->x + node->y) / 2;

	if(node->c != '\n'){
		node->leftChild->c = node->c;
		node->rightChild->c = node->c;
		node->c = '\n';
	}

	if( x <= middle )
		paint(x, y, c, node->leftChild);
	if( y > middle )
		paint(x, y, c, node->rightChild);
	

}

void query(int x, int y, treePointer node){

	if( node->c != '\n' ){
		if(color != node->c){
			if(color != '\n') fprintf(output, " %c",node->c);
			else fprintf(output, "%c",node->c);
		}
		color = node->c;
		return;
	}

	int middle = (node->x + node->y) / 2;

	if( x <= middle )
		query(x, y, node->leftChild);
	if( y > middle )
		query(x, y, node->rightChild);

}

void freeAll(treePointer node){

	if(node){
		freeAll(node->leftChild);
		freeAll(node->rightChild);
		free(node);
	}

}

int main(){

	char c;
    int x, y;
    int i, j, k;
    int numInstructor, numWall;
	
    input = fopen("input_3.txt","r");
    output = fopen("output_3.txt","w");

    fscanf(input, "%d%d", &numWall, &numInstructor);

	treePointer root = buildTree(0,numWall);
	root->c = '_';

	color = '\n';

    for(i = 0 ; i < numInstructor ; i++){

        fscanf(input, " %c", &c);
        
        switch (c)
        {
        case 'P':
            fscanf(input, "%d%d %c", &x, &y, &c);
            paint(x, y, c, root);
            break;
        case 'Q':
            fscanf(input, "%d%d", &x, &y);
            query(x, y, root);
			fprintf(output, "\n");
			color = '\n';
            break;
        default:
            printf("Error Occurs!\n");
            break;
        }
        
    }

	freeAll(root);
    
    fclose(input);
    fclose(output);

    return 0;
}

