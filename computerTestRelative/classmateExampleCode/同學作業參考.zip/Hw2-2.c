#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define max 101

typedef struct stackIngredient *ingredient;
struct stackIngredient{
	char str[max];
	struct stackIngredient *link;
};

typedef struct stackFood *food;
struct stackFood{
	int stoveNum;
	int cutNum;
	int finishNum;
	int totalNum;
	int time;
	
	char name[max];
	
	ingredient stoveHead;
	ingredient cutHead;
	
	struct stackFood *link;
};

typedef struct stackOrder *order;
struct stackOrder{
	int num;
	food thisFood;
	int arrival;
	int doStove;
	int doCut;
	int doFinish;
	int finished;
	int countdown;
	int money;
	int punish;
	struct stackOrder *link;
};

typedef struct {
	enum {
		stoving,
		cutting,
		finishing
	}doing;
	char ingredients[max];
	int timer;
	order orderDealt;
}player;

typedef struct queue *schedule;
struct queue{
	char str[max*2];
	struct queue *link;
};

int scheduleNum;
food foodTop;
player chef[2];
order orderTop, readyHead, readyTail;
schedule resultHead, resultTail;

void show(){
	
	schedule temp;
	FILE *output = fopen("players.txt","w");
	
	fprintf(output, "%d\n", scheduleNum);
	for(temp = resultHead ; temp ; temp = temp->link)
		fprintf(output, "%s\n", temp->str);
	
	fclose(output);
}

int nearTime(int a, int b){
	return a-b < 5 && a-b > -5 ? 1 : 0;
}

int countIngredient(ingredient *ptr, char str[]){
	
	int save;
	int i, cnt, num;
	char name[max];
	
	cnt = 0;
	save = *ptr ? 0 : 1;
	
	if(!strcmp(str, "x")) return 0;
	
	for(i=0, num = 0 ; 1 ; i++, num++){
		
		if( str[num] == ',' || str[num] == '\0'){
			
			name[i] = '\0';
			
			if(save){
				ingredient temp = (ingredient) malloc(sizeof(struct stackIngredient));
				strcpy(temp->str, name);
				
				temp->link = *ptr;
				*ptr = temp;
			}
			
			i=-1;
			cnt++;
			
			if(str[num]==',') continue;
			else break;
			
		}
		name[i] = str[num];
	}
	return cnt;
}

int countTime(food temp){
	
	int time;
	int stoveTime, cutTime;
	
	stoveTime = temp->stoveNum * 5;
	cutTime = temp->cutNum * 3;
	
	time = stoveTime > cutTime ? stoveTime : cutTime;
	
	time += 1 + temp->finishNum;
	
	return time;
	
}

void readRecipe(){
	
	int i, num;
	FILE *input = fopen("recipes.txt","r");
	char lineFood[max], lineStove[max], lineCut[max], lineFinish[max];
	
	fscanf(input, "%d", &num);
	
	for(i=0 ; i<num ; i++){
		food temp;
		fscanf(input, "%s %s %s %s", lineFood, lineStove, lineCut, lineFinish);
		
		temp = (food) malloc(sizeof(struct stackFood));
		strcpy(temp->name, lineFood);
		
		temp->stoveHead = NULL;
		temp->cutHead = NULL;
		
		temp->stoveNum = countIngredient(&temp->stoveHead, lineStove);
		temp->cutNum = countIngredient(&temp->cutHead, lineCut);
		temp->finishNum = countIngredient(&temp->stoveHead, lineFinish);
		
		temp->totalNum = temp->stoveNum + temp->cutNum + 1;
		
		temp->time = countTime(temp);
		
		temp->link = foodTop;
		foodTop = temp; 
		
	}
	
	food temp;
	fclose(input);
	
}

void readOrder(){
	
	int i, num;
	char name[max];
	FILE *input = fopen("orders.txt","r");
	
	fscanf(input, "%d",&num);
	
	for(i=0 ; i<num ; i++){
		order temp = (order) malloc(sizeof(struct stackOrder));
		fscanf(input, "%d %s %d %d %d %d", &temp->num, name, &temp->arrival, &temp->countdown, &temp->money, &temp->punish);
		
		temp->countdown -= temp->arrival;
		
		food searching;
		for(searching = foodTop; 1 ; searching = searching->link)
			if(! strcmp(searching->name, name)) break;
			
		temp->thisFood = searching;
		
		temp->doStove = 0;
		temp->doCut = 0;
		temp->doFinish = 0;
		temp->finished = 0;
		
		if(temp->countdown < temp->thisFood->time){
			free(temp);
			continue;
		}
		
		order lead;
		
		if(!orderTop || temp->arrival < orderTop->arrival){
			
			if(orderTop) temp->link = orderTop;
			else temp->link = NULL;
			
			orderTop = temp;
			
			continue;
		}
		
		for(lead = orderTop ; 1 ; lead = lead->link)
			if(! lead->link || temp->arrival < lead->link->arrival || temp->arrival == lead->link->arrival && temp->countdown < lead->link->countdown) break;
			
		temp->link = lead->link;
		lead->link = temp;
		
	}
	
	fclose(input);
}

int simulateMin(order temp){
	int time = 0;
	int stoveNum, cutNum, finishNum;
	
	stoveNum = (temp->thisFood->stoveNum - temp->doStove) * 5 ;
	cutNum = (temp->thisFood->cutNum - temp->doCut) * 3;
	
	time = stoveNum > cutNum ? stoveNum : cutNum;
	time += temp->doFinish ? 0 : temp->thisFood->finishNum + 1 ;
	
	return time;
}


void buffleReady(int time){
	
	// rewrite...
	if(! readyHead ) return ;
	
	// countdown
	order temp, lead;
	for(lead = readyHead ; lead ; lead = lead->link)
		if(time > lead->arrival) lead->countdown --;
	
	// forbidden useless order
	
	for(lead = readyHead ; lead && lead->link ; lead = lead->link){
		if(lead->link->finished == lead->link->thisFood->totalNum || lead->link->countdown < simulateMin(lead->link) ){
			
			temp = lead->link;
			lead->link = lead->link->link;
			
			if(temp == readyTail) readyTail = lead;
			free(temp);
		}
	}
	
	if(! readyHead ) return ;
	
	if(readyHead->finished == readyHead->thisFood->totalNum || readyHead->countdown < simulateMin(readyHead)){
		
		temp = readyHead;
		readyHead = readyHead->link;
		
		if(temp == readyTail) readyTail = NULL;
		free(temp);
		
	}
	
	if(! readyHead || readyHead == readyTail) return ;
	
	// change order
	int flag = 1;
	int previous, next;
	
	while(flag){
		
		flag = 0;
		for(lead = readyHead ; lead && lead->link && lead->link->link ; lead = lead->link){
		
			previous = lead->link->money + lead->link->link->punish ;
			next = lead->link->link->money + lead->link->punish;
			
			if(! nearTime(lead->link->countdown, lead->link->link->countdown) && lead->link->countdown > lead->link->link->countdown ){
				flag = 1;
				temp = lead->link->link->link;
				lead->link->link->link = lead->link;
				lead->link = lead->link->link;
				lead->link->link->link = temp;
			}
			else if( nearTime(lead->link->countdown, lead->link->link->countdown) && next > previous){
				flag = 1;
				temp = lead->link->link->link;
				lead->link->link->link = lead->link;
				lead->link = lead->link->link;
				lead->link->link->link = temp;
			}
			
			if(lead->link == readyTail) readyTail = lead->link->link ;
		}
	}
	
	
	lead = readyHead;
	previous = lead->money + lead->link->punish ;
	next = lead->link->money + lead->punish;
	
	if(! nearTime(lead->countdown, lead->link->countdown) && lead->countdown > lead->link->countdown ){
		temp = lead->link->link;
		lead->link->link = lead;
		readyHead = readyHead->link;
		readyHead->link->link = temp;
	}
	else if( nearTime(lead->countdown, lead->link->countdown) && next > previous){
		temp = lead->link->link;
		lead->link->link = lead;
		readyHead = readyHead->link;
		readyHead->link->link = temp;
	}
	
}

void getReady(){
	
	order temp = orderTop;
	orderTop = orderTop->link;
	
	if(! readyHead ) readyHead = temp;
	if( readyTail ) readyTail->link = temp;
	
	readyTail = temp;
	readyTail->link = NULL;
}

void addSchedule(char str[]){
	
	scheduleNum ++;
	schedule temp = (schedule) malloc(sizeof(struct queue));
	
	strcpy(temp->str, str);
	temp->link = NULL;
	
	if( resultTail ) resultTail->link = temp;
	if(! resultHead) resultHead = temp;
	
	resultTail = temp;
	
}

int main(){
	
	order temp;
	ingredient lead;
	char str[max*2];
	int i, time, cnt;
	
	foodTop = NULL;
	orderTop = NULL;
	
	readyHead = NULL;
	readyTail = NULL;
	
	resultHead = NULL;
	resultTail = NULL;
	
	scheduleNum = 0;
	
	readRecipe();
	readOrder();
	
	for(time = 0 ; orderTop || readyHead ; time ++){
		
		chef[0].timer --;
		chef[1].timer --;
		
		while(orderTop){
			
			if(nearTime(time, orderTop->arrival))
				getReady();
			else
				break; 
		}
		
		if(readyHead) buffleReady(time);
		
		for(i=0 ; i<2 ; i++){
			
			if(! readyHead ) break;
			if(chef[i].timer > 0) continue;
			if(chef[i].timer == 0 )	chef[i].orderDealt->finished ++;
			
			order temp;
			for(temp = readyHead ; temp ; temp = temp->link){
				if(time < temp->arrival) continue;
				
				if(i==0 && temp->doStove < temp->thisFood->stoveNum){
					if(temp->countdown < 5) continue;
					
					chef[i].orderDealt = temp;
					chef[i].doing = stoving;
					chef[i].timer = 5;
					
					for(cnt = 0, lead = temp->thisFood->stoveHead ; cnt < temp->doStove ; cnt++, lead = lead->link)
					
					strcpy(chef[i].ingredients, lead->str);
					temp->doStove ++;
					sprintf(str, "%d %d %d s %s", i+1, time, temp->num, lead->str);
					addSchedule(str);
					break;
				}
				else if(i==1 && temp->doCut < temp->thisFood->cutNum){
					if(temp->countdown < 3 ) continue;
					chef[i].orderDealt = temp;
					chef[i].doing = cutting;
					chef[i].timer = 3;
					
					for(cnt = 0, lead = temp->thisFood->cutHead ; cnt < temp->doCut ; cnt++, lead = lead->link)
					
					strcpy(chef[i].ingredients, lead->str);
					temp->doCut ++;
					sprintf(str, "%d %d %d c %s", i+1, time, temp->num, lead->str);
					addSchedule(str);
					break;
				}
				else if( temp->finished == temp->thisFood->totalNum-1 && temp->doStove == temp->thisFood->stoveNum && temp->doCut == temp->thisFood->cutNum && !temp->doFinish){
					if(temp->countdown < temp->thisFood->finishNum + 1) continue;
					chef[i].orderDealt = temp;
					chef[i].doing = finishing;
					chef[i].timer = 1 + temp->thisFood->finishNum;
					
					temp->doFinish ++;
					sprintf(str, "%d %d %d f", i+1, time, temp->num);
					addSchedule(str);
					break;
				}
			}
			
		}
		
	}
	show();
    return 0;
}
