#include <stdio.h>
#include <stdlib.h>

typedef struct pointer *queue;
struct pointer{
    int data;
    int depth;
    struct pointer *link;
    struct pointer *sheet;
    struct pointer *thread;
    char c;
};

int cnt = 0;

FILE *input;
FILE *output;

queue leafHead;
queue leafTail;

queue rootHead;
queue rootTail;

void add(queue *head, queue *tail, int data, char c, int depth, int ifLink){

    queue temp = (queue) malloc(sizeof(struct pointer));

    temp->data = data;
    temp->depth = depth;
    temp->sheet = NULL;
    temp->c = c;
    
    if(! *head) *head = temp;
    
    if(ifLink) temp->link = *tail;
    temp->thread = *tail;
    
    *tail = temp;
    
}

void addSheet(queue *dot, queue *child){

    queue temp, lead;
    temp = (*dot)->sheet;

    if((*child)->c != '@'){
        (*dot)->sheet = *child;
        (*child)->sheet = temp;
    }
    else{
        (*dot)->sheet = (*child)->sheet;
        for(lead = *child ; lead->sheet ;  lead = lead->sheet);
        lead->sheet = temp;
    }
     
}

void delete(char c, int data, queue sheet){

    queue temp, pre;

    for(temp = rootTail ; temp ; temp = temp->thread){
        if(temp->c == c && temp->data == data && temp->sheet == sheet)
            break;

        pre = temp;
    }

    pre->thread = temp->thread;
    if(c == '@') free(temp);

}

void huffman(){

    queue one, two, temp;

    one = rootTail;
    two = rootTail->thread;

    while(1){

        for(temp = rootTail; temp ; temp = temp->thread){

            if(temp == one || temp == two) continue;

            if(temp->data < one->data){
                one = temp;
                break;
            }

            if(temp->data < two->data){
                two = temp;
                break;
            }

        }

        if(!temp) break;

    }

    for(temp = one; temp ; temp = temp->sheet)
        temp->depth ++;
        
    for(temp = two; temp ; temp = temp->sheet)
        temp->depth ++;

    add(&rootHead, &rootTail, one->data + two->data, '@', 0 , 0);

    addSheet(&rootTail, &one);
    addSheet(&rootTail, &two);

    delete(one->c, one->data, one->sheet);
    delete(two->c, two->data, two->sheet);

    cnt--;

}

int main(){

    char c;
    int i, j, k, num, ans;

    input = fopen("input_2.txt","r");
    output = fopen("output_2.txt","w");

    while(1){
        fscanf(input, "%d%c", &num, &c);
        if(!num) break;

        ans = 0;
        cnt = 0;
        int form[91] = {0};

        rootHead = NULL;
        rootTail = NULL;
        leafHead = NULL;
        leafTail = NULL;

        for(i=0 ; i<num ;){

            fscanf(input,"%c",&c);
            
            if(c == '\n') {
                i++;
                continue;
            }

            form[c - ' '] ++;

        }
        
        for(i=0 ; i<91 ; i++){
        	
            if(form[i] == 0) continue;
            
            cnt++;

            add(&rootHead, &rootTail, form[i], ' ' + i, 0, 1);
        }

        leafHead = rootHead;
        leafTail = rootTail;

        queue temp = NULL;

        if(cnt > 1){

            while(cnt != 1)
                huffman();

            for(; leafTail ; leafTail = leafTail->link){
                if(temp) free(temp);
                ans = ans + leafTail->depth*leafTail->data;
                temp = leafTail;
            }
        }
        else if(cnt == 1)
            ans = leafTail->data;
        else    
            ans = 0;
        
        if(temp) free(temp);
        if(rootTail) free(rootTail); 

        fprintf(output, "%d\n\n", ans);
        
    }

    fclose(input);
    fclose(output);

    return 0;
}
