#include <stdio.h>
#include <stdlib.h>

typedef struct treeNode *tree;
struct treeNode{
    int data;
    tree rightChild;
    tree leftChild;
};

tree root;
FILE *output;

void insert(int data){

    tree lead, tail;
    tree temp = (tree) malloc(sizeof(struct treeNode));

    temp->data = data;
    temp->leftChild = NULL;
    temp->rightChild = NULL;

    if(!root)
        root = temp;
    else{

        lead = root;

        while(lead){

            tail = lead;

            if(temp->data > lead->data)
                lead = lead->rightChild;
            else if(temp->data < lead->data)
                lead = lead->leftChild;
            else
                break;

        }

        if(!lead){

            if(temp->data > tail->data)
                tail->rightChild = temp;
            else if(temp->data < tail->data)
                tail->leftChild = temp;

        }
        else
            free(temp);

    }

}

void delete(int data){

    int temp;
    tree lead, middle, tail, deleteNode;

    tail = NULL;
    middle = NULL;

    for(deleteNode = root ; deleteNode ;){

        tail = middle;
        middle = deleteNode;

        if(data > deleteNode->data)
            deleteNode = deleteNode->rightChild;
        else if(data < deleteNode->data)
            deleteNode = deleteNode->leftChild;
        else
            break;

    }

    if(!deleteNode) return;

    lead = deleteNode;
    middle = NULL;

    if(deleteNode->leftChild){

        lead = lead->leftChild;
        tail = NULL;

        while(lead){
            tail = middle;
            middle = lead;
            lead = lead->rightChild;
        }

        deleteNode->data = middle->data;

        if(tail)
            tail->rightChild = middle->leftChild;
        else
        	deleteNode->leftChild = middle->leftChild;
        
        free(middle);

    }
    else if(deleteNode->rightChild){

        lead = lead->rightChild;
        tail = NULL;

        while(lead){
            tail = middle;
            middle = lead;
            lead = lead->leftChild;
        }

        deleteNode->data = middle->data;

        if(tail)
            tail->leftChild = middle->rightChild;
        else
        	deleteNode->rightChild = middle->rightChild;
        
        free(middle);
    }
    else{

        if(deleteNode == root)
            root = NULL;
        else if(deleteNode->data > tail->data)
            tail->rightChild = NULL;
        else if(deleteNode->data < tail->data)
            tail->leftChild = NULL;

        free(deleteNode);
    }
    
}

void search(int data){
    
    int cnt;
    tree lead;

    for(cnt = 1, lead = root ; lead ; cnt++){

        if(data > lead->data)
            lead = lead->rightChild;
        else if(data < lead->data)
            lead = lead->leftChild;
        else
            break;

    }

    if(lead)
        fprintf(output, "%d\n",cnt);

}

void road(int data, int info){

    int record;
    tree right, left;
    tree lead;

    record = 0;

    for(lead = root; lead ;){

        if(data > lead->data && info > lead->data)
            lead = lead->rightChild;
        else if(data < lead->data && info < lead->data)
            lead = lead->leftChild;
        else
            break;

    }

    if(!lead) return;

    right = lead;
    while(right){

        if(right->data > 0) record += right->data;
        //printf("%d %d\n",right->data, record);

        if(data > right->data)
            right = right->rightChild;
        else if(data < right->data)
            right = right->leftChild;
        else
            break;
        
    }

    left = lead;
    while(left){

        if(left->data > 0) record += left->data;
        //printf("%d %d\n",left->data, record);

        if(info > left->data)
            left = left->rightChild;
        else if(info < left->data)
            left = left->leftChild;
        else
            break;

    }

    if(lead->data > 0) record -= lead->data;
    //printf("%d %d\n",lead->data, record);

    if(left && right && right->data == data && left->data == info)
        fprintf(output, "%d\n", record);
    
}

void freeAll(tree temp){
	
    if(temp){
        freeAll(temp->leftChild);
        freeAll(temp->rightChild);
        free(temp);
    }
}

int main(){

    FILE *input;

    char c;
    
    int cnt;
    int i, j, k;
    int data, info;
    int numNode, numInstructor;

    cnt = 1;
    input = fopen("input_1.txt","r");
    output = fopen("output_1.txt", "w");

    while(1){

        fscanf(input, "%d %d", &numNode, &numInstructor);
        if(! numNode && !numInstructor) break;

        root = NULL;
        fprintf(output, "# %d\n",cnt);

        for(i = 0; i < numNode ; i++){
            fscanf(input, "%d", &data);
            insert(data);
        }

        for( j = 0; j < numInstructor ; j++){
            fscanf(input, " %c", &c);

            switch (c)
            {
            case 'I':
                fscanf(input, "%d", &data);
                //fprintf(output, "--I %d--\n",data);
                insert(data);
                break;
            case 'D':
                fscanf(input, "%d", &data);
                //fprintf(output, "--D %d--\n",data);
                delete(data);
                break;
            case 'Q':
                fscanf(input, "%d", &data);
                //fprintf(output, "--Q %d--\n",data);
                search(data);
                break;
            case 'P':
                fscanf(input, "%d %d", &data, &info);
                //printf("P %d %d\n",data, info);
                road(data, info);
                break;
            default:
                //printf("Wrong Instructor, Please Enter Again\n");
                break;
            }
        }

        cnt++;
        if(root) freeAll(root);
    }

    fclose(input);
    fclose(output);
    return 0;
}
